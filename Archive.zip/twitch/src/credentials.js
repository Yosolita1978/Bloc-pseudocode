const Client_ID = 'wmze1k7kohuh0scsvaahk455ngm1g2';

export default Client_ID;
